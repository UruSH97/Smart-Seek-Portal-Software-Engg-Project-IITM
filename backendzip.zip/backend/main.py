from application.resources.api import (
    ModuleResource, EnrollmentResource, LectureResource, NoteResource,
    AssignmentResource, ProgrammingAssignmentResource, TestCaseResource,
    QuestionResource, SubmissionResource,
    CourseResource, StudentDetailsManagementResource, AssignmentStatusResource,
    CourseStatisticsResource,
    AdminCourseManagementResource
)
from application.resources.ai_api import (
    VirtualInstructorQueryResource,
    InstructorContentPlannerResource
)

import logging
import os
from flask import Flask, render_template
from flask_cors import CORS
from application.config import LocalDevelopmentConfig
from application.database import db
from application.models import (
    User, Role
)
from flask_restful import Api
from flask_security import (
    Security, hash_password, SQLAlchemySessionUserDatastore)


# applying logging in the project
logging.basicConfig(
    filename='debug.log', level=logging.DEBUG,
    format=f'%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s')
user_datastore = SQLAlchemySessionUserDatastore(db.session, User, Role)


app, api = None, None


def create_app():
    app = Flask(__name__, template_folder="templates")
    if os.getenv('ENV', "development") == "production":
        # app.logger.info("Currently no production is being setup")
        raise Exception("Currently no production config is setup.")
    else:
        # app.logger.info("Starting local development")
        app.config.from_object(LocalDevelopmentConfig)
    db.init_app(app)
    app.app_context().push()
    db.create_all()

    app.security = Security(app, user_datastore)

    roles = [
        ('admin', 'Administrator'),
        ('user', 'User'),
        ('superuser', 'Superuser')
    ]
    for name, description in roles:
        role = Role.query.filter_by(name=name).first()
        if role is None:
            role = Role(name=name, description=description)
            db.session.add(role)
    db.session.commit()
    # To add admin on initializing of database
    role = Role.query.filter_by(name='admin').first()
    if not app.security.datastore.find_user(email="24f20021team@sep.com"):
        app.security.datastore.create_user(
            email="24f20021team@sep.com", password=hash_password("password"))
    db.session.commit()
    user = app.security.datastore.find_user(email="24f20021team@sep.com")
    app.security.datastore.add_role_to_user(user=user, role=role)
    db.session.commit()
    api = Api(app)
    return app, api


app, api = create_app()

# app.logger.info("Starting local development")
cors = CORS(app, resources={
    r"/api/*": {"origins": "http://localhost:5173"}})

from application.resources.auth_api import *

@app.errorhandler(404)
def page_not_found(e):
    # setting 404 status explicitly
    return render_template('404.html'), 404


api.add_resource(EnrollmentResource,
                 '/enrollments/<string:enrollment_id>')
api.add_resource(ModuleResource, '/modules/<string:module_id>')
api.add_resource(CourseResource, '/courses/<string:course_id>', '/courses')
# Repeat the above pattern for the remaining resources
api.add_resource(LectureResource, '/lectures/<string:lecture_id>')
api.add_resource(NoteResource, '/notes/<string:note_id>')
api.add_resource(AssignmentResource, '/assignments/<string:assignment_id>')
api.add_resource(ProgrammingAssignmentResource,
                 '/programming_assignments/<string:programming_assignment_id>')
api.add_resource(TestCaseResource, '/test_cases/<string:test_case_id>')
api.add_resource(QuestionResource, '/questions/<string:question_id>')
api.add_resource(SubmissionResource, '/submissions/<string:submission_id>')

###########AI Resources ############################################################
api.add_resource(VirtualInstructorQueryResource,
                 '/virtual_instructor_query/<int:course_id>/<int:student_id>',  # GET and DELETE endpoints
                 '/virtual_instructor_query'  # POST endpoint
                )
api.add_resource(InstructorContentPlannerResource,
                 '/instructor_content/<string:instructor_id>/<string:course_id>',  # GET endpoint
                 '/instructor_content',  # POST endpoint
                 '/instructor_content/<string:query_id>'  # DELETE endpoint
)
#######################################################################################
api.add_resource(CourseStatisticsResource,
                 '/course_statistics/<string:statistics_id>')
api.add_resource(AdminCourseManagementResource,
                 '/admin_course_management/<string:management_id>')
api.add_resource(StudentDetailsManagementResource,
                 '/student_details_management/<string:management_id>')
api.add_resource(AssignmentStatusResource,
                 '/assignment_status/<string:status_id>')

if __name__ == "__main__":
    # Run the Flask app
    app.run(host='0.0.0.0', port=8000)
