def add(x,y):
    return x+y
def test_add():
    z=add(1,2)
    assert z==3
