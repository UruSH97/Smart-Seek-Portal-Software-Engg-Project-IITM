from flask_restful import (
    Resource,
    fields,
    marshal_with,
    reqparse,
)
from application.database import db
from ..models import (
    Course,
    Enrollment,
    Module,
    Note,
    Lecture,
    Assignment,
    ProgrammingAssignment,
    TestCase,
    RolesUsers,
    Question,
    Submission,
    VirtualInstructorQuery,
    InstructorContentPlanner,
    CourseStatistics,
    AdminCourseManagement,
    StudentDetailsManagement,
    AssignmentStatus
)

course_fields = {
    'id': fields.Integer,
    'title': fields.String,
    'description': fields.String
}

user_fields = {
    'id': fields.Integer,
    'username': fields.String,
    'email': fields.String
}

enrollment_fields = {
    'id': fields.Integer,
    'student_id': fields.String,
    'course_id': fields.String
}

module_fields = {
    'id': fields.Integer,
    'course_id': fields.String,
    'title': fields.String,
    'description': fields.String,
    'week': fields.Integer
}

note_fields = {
    'id': fields.String,
    'module_id': fields.String,
    'title': fields.String,
    'content': fields.String
}

lecture_fields = {
    'id': fields.String,
    'module_id': fields.String,
    'title': fields.String,
    'content': fields.String
}

assignment_fields = {
    'id': fields.String,
    'title': fields.String,
    'description': fields.String
}

programming_assignment_fields = {
    'id': fields.String,
    'assignment_id': fields.String,
    'language': fields.String
}

test_case_fields = {
    'id': fields.String,
    'assignment_id': fields.String,
    'input': fields.String,
    'output': fields.String
}

question_fields = {
    'id': fields.String,
    'assignment_id': fields.String,
    'question_text': fields.String
}

submission_fields = {
    'id': fields.String,
    'assignment_id': fields.String,
    'student_id': fields.String
}

virtual_instructor_query_fields = {
    'id': fields.String,
    'student_id': fields.String,
    'query': fields.String
}

instructor_content_planner_fields = {
    'id': fields.String,
    'course_id': fields.String
}

course_statistics_fields = {
    'id': fields.String,
    'course_id': fields.String
}


class CourseResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('title', type=str, required=True)
        self.parser.add_argument('description', type=str, required=True)

    @marshal_with(course_fields)
    def get(self, course_id):
        course = Course.query.get(course_id)
        if course:
            return course
        else:
            return {'message': 'Course not found'}, 404

    @marshal_with(course_fields)
    def post(self):
        args = self.parser.parse_args()
        course = Course(title=args['title'], description=args['description'])
        db.session.add(course)
        db.session.commit()
        return course, 201

    @marshal_with(course_fields)
    def put(self, course_id):
        course = Course.query.get(course_id)
        if course:
            args = self.parser.parse_args()
            course.title = args['title']
            course.description = args['description']
            db.session.commit()
            return course
        else:
            return {'message': 'Course not found'}, 404

    def delete(self, course_id):
        course = Course.query.get(course_id)
        if course:
            db.session.delete(course)
            db.session.commit()
            return {'message': 'Course deleted'}
        else:
            return {'message': 'Course not found'}, 404


class EnrollmentResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('student_id', type=str, required=True)
        self.parser.add_argument('course_id', type=str, required=True)
        self.parser.add_argument(
            'enrollment_date', type=str, required=True)
        self.parser.add_argument('status', type=str, required=True)

    @marshal_with(enrollment_fields)
    def get(self, enrollment_id):
        enrollment = Enrollment.query.get(enrollment_id)
        if enrollment:
            return enrollment
        else:
            return {'message': 'Enrollment not found'}, 404

    @marshal_with(enrollment_fields)
    def post(self):
        args = self.parser.parse_args()
        enrollment = Enrollment(student_id=args['student_id'], course_id=args['course_id'],
                                enrollment_date=args['enrollment_date'], status=args['status'])
        db.session.add(enrollment)
        db.session.commit()
        return enrollment, 201

    @marshal_with(enrollment_fields)
    def put(self, enrollment_id):
        enrollment = Enrollment.query.get(enrollment_id)
        if enrollment:
            args = self.parser.parse_args()
            enrollment.student_id = args['student_id']
            enrollment.course_id = args['course_id']
            enrollment.enrollment_date = args['enrollment_date']
            enrollment.status = args['status']
            db.session.commit()
            return enrollment
        else:
            return {'message': 'Enrollment not found'}, 404

    def delete(self, enrollment_id):
        enrollment = Enrollment.query.get(enrollment_id)
        if enrollment:
            db.session.delete(enrollment)
            db.session.commit()
            return {'message': 'Enrollment deleted'}
        else:
            return {'message': 'Enrollment not found'}, 404


class ModuleResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('course_id', type=str, required=True)
        self.parser.add_argument('title', type=str, required=True)
        self.parser.add_argument(
            'description', type=str, required=True)
        self.parser.add_argument('week', type=int, required=True)
        self.parser.add_argument('created_at', type=str, required=True)
        self.parser.add_argument('updated_at', type=str, required=True)

    @marshal_with(module_fields)
    def get(self, module_id):
        module = Module.query.get(module_id)
        if module:
            return module
        else:
            return {'message': 'Module not found'}, 404

    @marshal_with(module_fields)
    def post(self):
        args = self.parser.parse_args()
        module = Module(course_id=args['course_id'], title=args['title'], description=args['description'],
                        week=args['week'], created_at=args['created_at'], updated_at=args['updated_at'])
        db.session.add(module)
        db.session.commit()
        return module, 201

    @marshal_with(module_fields)
    def put(self, module_id):
        module = Module.query.get(module_id)
        if module:
            args = self.parser.parse_args()
            module.course_id = args['course_id']
            module.title = args['title']
            module.description = args['description']
            module.week = args['week']
            module.created_at = args['created_at']
            module.updated_at = args['updated_at']
            db.session.commit()
            return module
        else:
            return {'message': 'Module not found'}, 404

    def delete(self, module_id):
        module = Module.query.get(module_id)
        if module:
            db.session.delete(module)
            db.session.commit()
            return {'message': 'Module deleted'}
        else:
            return {'message': 'Module not found'}, 404


class LectureResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('module_id', type=str, required=True)
        self.parser.add_argument('title', type=str, required=True)
        self.parser.add_argument('content', type=str, required=True)

    @marshal_with(lecture_fields)
    def get(self, lecture_id):
        lecture = Lecture.query.get(lecture_id)
        if lecture:
            return lecture
        else:
            return {'message': 'Lecture not found'}, 404

    @marshal_with(lecture_fields)
    def post(self):
        args = self.parser.parse_args()
        lecture = Lecture(
            module_id=args['module_id'], title=args['title'], content=args['content'])
        db.session.add(lecture)
        db.session.commit()
        return lecture, 201

    @marshal_with(lecture_fields)
    def put(self, lecture_id):
        lecture = Lecture.query.get(lecture_id)
        if lecture:
            args = self.parser.parse_args()
            lecture.module_id = args['module_id']
            lecture.title = args['title']
            lecture.content = args['content']
            db.session.commit()
            return lecture
        else:
            return {'message': 'Lecture not found'}, 404

    def delete(self, lecture_id):
        lecture = Lecture.query.get(lecture_id)
        if lecture:
            db.session.delete(lecture)
            db.session.commit()
            return {'message': 'Lecture deleted'}
        else:
            return {'message': 'Lecture not found'}, 404


class NoteResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('module_id', type=str, required=True)
        self.parser.add_argument('title', type=str, required=True)
        self.parser.add_argument('content', type=str, required=True)

    @marshal_with(note_fields)
    def get(self, note_id):
        note = Note.query.get(note_id)
        if note:
            return note
        else:
            return {'message': 'Note not found'}, 404

    @marshal_with(note_fields)
    def post(self):
        args = self.parser.parse_args()
        note = Note(module_id=args['module_id'],
                    title=args['title'], content=args['content'])
        db.session.add(note)
        db.session.commit()
        return note, 201

    @marshal_with(note_fields)
    def put(self, note_id):
        note = Note.query.get(note_id)
        if note:
            args = self.parser.parse_args()
            note.module_id = args['module_id']
            note.title = args['title']
            note.content = args['content']
            db.session.commit()
            return note
        else:
            return {'message': 'Note not found'}, 404

    def delete(self, note_id):
        note = Note.query.get(note_id)
        if note:
            db.session.delete(note)
            db.session.commit()
            return {'message': 'Note deleted'}
        else:
            return {'message': 'Note not found'}, 404


class AssignmentResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('title', type=str, required=True)
        self.parser.add_argument('description', type=str, required=True)

    @marshal_with(assignment_fields)
    def get(self, assignment_id):
        assignment = Assignment.query.get(assignment_id)
        if assignment:
            return assignment
        else:
            return {'message': 'Assignment not found'}, 404

    @marshal_with(assignment_fields)
    def post(self):
        args = self.parser.parse_args()
        assignment = Assignment(
            title=args['title'], description=args['description'])
        db.session.add(assignment)
        db.session.commit()
        return assignment, 201

    @marshal_with(assignment_fields)
    def put(self, assignment_id):
        assignment = Assignment.query.get(assignment_id)
        if assignment:
            args = self.parser.parse_args()
            assignment.title = args['title']
            assignment.description = args['description']
            db.session.commit()
            return assignment
        else:
            return {'message': 'Assignment not found'}, 404

    def delete(self, assignment_id):
        assignment = Assignment.query.get(assignment_id)
        if assignment:
            db.session.delete(assignment)
            db.session.commit()
            return {'message': 'Assignment deleted'}
        else:
            return {'message': 'Assignment not found'}, 404


class ProgrammingAssignmentResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('assignment_id', type=str, required=True)
        self.parser.add_argument('language', type=str, required=True)

    @marshal_with(programming_assignment_fields)
    def get(self, programming_assignment_id):
        programming_assignment = ProgrammingAssignment.query.get(
            programming_assignment_id)
        if programming_assignment:
            return programming_assignment
        else:
            return {'message': 'Programming Assignment not found'}, 404

    @marshal_with(programming_assignment_fields)
    def post(self):
        args = self.parser.parse_args()
        programming_assignment = ProgrammingAssignment(
            assignment_id=args['assignment_id'], language=args['language'])
        db.session.add(programming_assignment)
        db.session.commit()
        return programming_assignment, 201

    @marshal_with(programming_assignment_fields)
    def put(self, programming_assignment_id):
        programming_assignment = ProgrammingAssignment.query.get(
            programming_assignment_id)
        if programming_assignment:
            args = self.parser.parse_args()
            programming_assignment.assignment_id = args['assignment_id']
            programming_assignment.language = args['language']
            db.session.commit()
            return programming_assignment
        else:
            return {'message': 'Programming Assignment not found'}, 404

    def delete(self, programming_assignment_id):
        programming_assignment = ProgrammingAssignment.query.get(
            programming_assignment_id)
        if programming_assignment:
            db.session.delete(programming_assignment)
            db.session.commit()
            return {'message': 'Programming Assignment deleted'}
        else:
            return {'message': 'Programming Assignment not found'}, 404


class TestCaseResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('assignment_id', type=str, required=True)
        self.parser.add_argument('input', type=str, required=True)
        self.parser.add_argument('output', type=str, required=True)

    @marshal_with(test_case_fields)
    def get(self, test_case_id):
        test_case = TestCase.query.get(test_case_id)
        if test_case:
            return test_case
        else:
            return {'message': 'Test Case not found'}, 404

    @marshal_with(test_case_fields)
    def post(self):
        args = self.parser.parse_args()
        test_case = TestCase(
            assignment_id=args['assignment_id'], input=args['input'], output=args['output'])
        db.session.add(test_case)
        db.session.commit()
        return test_case, 201

    @marshal_with(test_case_fields)
    def put(self, test_case_id):
        test_case = TestCase.query.get(test_case_id)
        if test_case:
            args = self.parser.parse_args()
            test_case.assignment_id = args['assignment_id']
            test_case.input = args['input']
            test_case.output = args['output']
            db.session.commit()
            return test_case
        else:
            return {'message': 'Test Case not found'}, 404

    def delete(self, test_case_id):
        test_case = TestCase.query.get(test_case_id)
        if test_case:
            db.session.delete(test_case)
            db.session.commit()
            return {'message': 'Test Case deleted'}
        else:
            return {'message': 'Test Case not found'}, 404


class QuestionResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('assignment_id', type=str, required=True)
        self.parser.add_argument('question_text', type=str, required=True)

    @marshal_with(question_fields)
    def get(self, question_id):
        question = Question.query.get(question_id)
        if question:
            return question
        else:
            return {'message': 'Question not found'}, 404

    @marshal_with(question_fields)
    def post(self):
        args = self.parser.parse_args()
        question = Question(
            assignment_id=args['assignment_id'], question_text=args['question_text'])
        db.session.add(question)
        db.session.commit()
        return question, 201

    @marshal_with(question_fields)
    def put(self, question_id):
        question = Question.query.get(question_id)
        if question:
            args = self.parser.parse_args()
            question.assignment_id = args['assignment_id']
            question.question_text = args['question_text']
            db.session.commit()
            return question
        else:
            return {'message': 'Question not found'}, 404

    def delete(self, question_id):
        question = Question.query.get(question_id)
        if question:
            db.session.delete(question)
            db.session.commit()
            return {'message': 'Question deleted'}
        else:
            return {'message': 'Question not found'}, 404


class SubmissionResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('assignment_id', type=str, required=True)
        self.parser.add_argument('student_id', type=str, required=True)

    @marshal_with(submission_fields)
    def get(self, submission_id):
        submission = Submission.query.get(submission_id)
        if submission:
            return submission
        else:
            return {'message': 'Submission not found'}, 404

    @marshal_with(submission_fields)
    def post(self):
        args = self.parser.parse_args()
        submission = Submission(
            assignment_id=args['assignment_id'], student_id=args['student_id'])
        db.session.add(submission)
        db.session.commit()
        return submission, 201

    @marshal_with(submission_fields)
    def put(self, submission_id):
        submission = Submission.query.get(submission_id)
        if submission:
            args = self.parser.parse_args()
            submission.assignment_id = args['assignment_id']
            submission.student_id = args['student_id']
            db.session.commit()
            return submission
        else:
            return {'message': 'Submission not found'}, 404

    def delete(self, submission_id):
        submission = Submission.query.get(submission_id)
        if submission:
            db.session.delete(submission)
            db.session.commit()
            return {'message': 'Submission deleted'}
        else:
            return {'message': 'Submission not found'}, 404


# class VirtualInstructorQueryResource(Resource):
#     def __init__(self):
#         self.parser = reqparse.RequestParser()
#         self.parser.add_argument('student_id', type=str, required=True)
#         self.parser.add_argument('query', type=str, required=True)

#     @marshal_with(virtual_instructor_query_fields)
#     def get(self, query_id):
#         query = VirtualInstructorQuery.query.get(query_id)
#         if query:
#             return query
#         else:
#             return {'message': 'Virtual Instructor Query not found'}, 404

#     @marshal_with(virtual_instructor_query_fields)
#     def post(self):
#         args = self.parser.parse_args()
#         query = VirtualInstructorQuery(
#             student_id=args['student_id'], query=args['query'])
#         db.session.add(query)
#         db.session.commit()
#         return query, 201

#     @marshal_with(virtual_instructor_query_fields)
#     def put(self, query_id):
#         query = VirtualInstructorQuery.query.get(query_id)
#         if query:
#             args = self.parser.parse_args()
#             query.student_id = args['student_id']
#             query.query = args['query']
#             db.session.commit()
#             return query
#         else:
#             return {'message': 'Virtual Instructor Query not found'}, 404

#     def delete(self, query_id):
#         query = VirtualInstructorQuery.query.get(query_id)
#         if query:
#             db.session.delete(query)
#             db.session.commit()
#             return {'message': 'Virtual Instructor Query deleted'}
#         else:
#             return {'message': 'Virtual Instructor Query not found'}, 404


# class InstructorContentPlannerResource(Resource):
#     def __init__(self):
#         self.parser = reqparse.RequestParser()
#         self.parser.add_argument('course_id', type=str, required=True)

#     @marshal_with(instructor_content_planner_fields)
#     def get(self, planner_id):
#         planner = InstructorContentPlanner.query.get(planner_id)
#         if planner:
#             return planner
#         else:
#             return {'message': 'Instructor Content Planner not found'}, 404

#     @marshal_with(instructor_content_planner_fields)
#     def post(self):
#         args = self.parser.parse_args()
#         planner = InstructorContentPlanner(course_id=args['course_id'])
#         db.session.add(planner)
#         db.session.commit()
#         return planner, 201

#     @marshal_with(instructor_content_planner_fields)
#     def put(self, planner_id):
#         planner = InstructorContentPlanner.query.get(planner_id)
#         if planner:
#             args = self.parser.parse_args()
#             planner.course_id = args['course_id']
#             db.session.commit()
#             return planner
#         else:
#             return {'message': 'Instructor Content Planner not found'}, 404

#     def delete(self, planner_id):
#         planner = InstructorContentPlanner.query.get(planner_id)
#         if planner:
#             db.session.delete(planner)
#             db.session.commit()
#             return {'message': 'Instructor Content Planner deleted'}
#         else:
#             return {'message': 'Instructor Content Planner not found'}, 404


class CourseStatisticsResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('course_id', type=str, required=True)

    @marshal_with(course_statistics_fields)
    def get(self, statistics_id):
        statistics = CourseStatistics.query.get(statistics_id)
        if statistics:
            return statistics
        else:
            return {'message': 'Course Statistics not found'}, 404

    @marshal_with(course_statistics_fields)
    def post(self):
        args = self.parser.parse_args()
        statistics = CourseStatistics(course_id=args['course_id'])
        db.session.add(statistics)
        db.session.commit()
        return statistics, 201

    @marshal_with(course_statistics_fields)
    def put(self, statistics_id):
        statistics = CourseStatistics.query.get(statistics_id)
        if statistics:
            args = self.parser.parse_args()
            statistics.course_id = args['course_id']
            db.session.commit()
            return statistics
        else:
            return {'message': 'Course Statistics not found'}, 404

    def delete(self, statistics_id):
        statistics = CourseStatistics.query.get(statistics_id)
        if statistics:
            db.session.delete(statistics)
            db.session.commit()
            return {'message': 'Course Statistics deleted'}
        else:
            return {'message': 'Course Statistics not found'}, 404


class AdminCourseManagementResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('course_id', type=str, required=True)

    @marshal_with(course_fields)
    def get(self, management_id):
        management = AdminCourseManagement.query.get(management_id)
        if management:
            return management
        else:
            return {'message': 'Admin Course Management not found'}, 404

    @marshal_with(course_fields)
    def post(self):
        args = self.parser.parse_args()
        management = AdminCourseManagement(course_id=args['course_id'])
        db.session.add(management)
        db.session.commit()
        return management, 201

    @marshal_with(course_fields)
    def put(self, management_id):
        management = AdminCourseManagement.query.get(management_id)
        if management:
            args = self.parser.parse_args()
            management.course_id = args['course_id']
            db.session.commit()
            return management
        else:
            return {'message': 'Admin Course Management not found'}, 404

    def delete(self, management_id):
        management = AdminCourseManagement.query.get(management_id)
        if management:
            db.session.delete(management)
            db.session.commit()
            return {'message': 'Admin Course Management deleted'}
        else:
            return {'message': 'Admin Course Management not found'}, 404


class StudentDetailsManagementResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('management_id', type=str, required=True)

    @marshal_with(user_fields)
    def get(self, management_id):
        management = StudentDetailsManagement.query.get(management_id)
        if management:
            return management
        else:
            return {'message': 'Student Details Management not found'}, 404

    @marshal_with(user_fields)
    def post(self):
        args = self.parser.parse_args()
        management = StudentDetailsManagement(
            management_id=args['management_id'])
        db.session.add(management)
        db.session.commit()
        return management, 201

    @marshal_with(user_fields)
    def put(self, management_id):
        management = StudentDetailsManagement.query.get(management_id)
        if management:
            args = self.parser.parse_args()
            management.management_id = args['management_id']
            db.session.commit()
            return management
        else:
            return {'message': 'Student Details Management not found'}, 404

    def delete(self, management_id):
        management = StudentDetailsManagement.query.get(management_id)
        if management:
            db.session.delete(management)
            db.session.commit()
            return {'message': 'Student Details Management deleted'}
        else:
            return {'message': 'Student Details Management not found'}, 404


class AssignmentStatusResource(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('status_id', type=str, required=True)

    @marshal_with(assignment_fields)
    def get(self, status_id):
        status = AssignmentStatus.query.get(status_id)
        if status:
            return status
        else:
            return {'message': 'Assignment Status not found'}, 404

    @marshal_with(assignment_fields)
    def post(self):
        args = self.parser.parse_args()
        status = AssignmentStatus(status_id=args['status_id'])
        db.session.add(status)
        db.session.commit()
        return status, 201

    @marshal_with(assignment_fields)
    def put(self, status_id):
        status = AssignmentStatus.query.get(status_id)
        if status:
            args = self.parser.parse_args()
            status.status_id = args['status_id']
            db.session.commit()
            return status
        else:
            return {'message': 'Assignment Status not found'}, 404

    def delete(self, status_id):
        status = AssignmentStatus.query.get(status_id)
        if status:
            db.session.delete(status)
            db.session.commit()
            return {'message': 'Assignment Status deleted'}
        else:
            return {'message': 'Assignment Status not found'}, 404
