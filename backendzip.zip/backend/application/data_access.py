# from application.models import Venue
# from main import cache

# @cache.cached(timeout=50, key_prefix="get_all_venues")
# def get_all_venues():
#     venues=Venue.query.all()
#     return venues

# def get_value():
#     return get_all_venues()
