### Fisrt You will have to create the virtul environment
#### for windows run the command
- python -m venv .env

### then activate the environment
#### for windows run the command
- .env\scripts\activate
### Now install all the required modules/library from requirements.txt
#### for windows run the command
- pip install -r requirements.txt

#### That's all now you can run the project
#### by running the main.py python file
